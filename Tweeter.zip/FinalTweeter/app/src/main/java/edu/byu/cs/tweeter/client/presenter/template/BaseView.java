package edu.byu.cs.tweeter.client.presenter.template;

public interface BaseView {
    void displayErrorMessage(String message);
}
