package edu.byu.cs.tweeter.client.model.service.observer;

public interface NotificationObserver extends ServiceObserver{
    void handleSuccess();
}
